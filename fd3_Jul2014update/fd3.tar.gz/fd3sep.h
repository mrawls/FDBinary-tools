
double fd3sep ( long K, long M, long N, double **dftobs, double *sig,
   double **rvm, double **lfm, double **dftmod, double **dftres ) ;

void dft_fwd ( long m, long n, double **mxin, double **mxout ) ;

void dft_bck ( long m, long n, double **mxin, double **mxout ) ;

