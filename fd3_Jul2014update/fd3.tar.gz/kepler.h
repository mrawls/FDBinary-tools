double kepler_psiofmu ( double mu, double ecc ) ;
double kepler_thetaofmu ( double mu, double ecc ) ;
double kepler_rv ( double mu, double ecc, double omega ) ;
double kepler_lite ( double mu, double ecc, double omega ) ;
double kepler_sep ( double mu, double ecc, double omega, double inc ) ;
