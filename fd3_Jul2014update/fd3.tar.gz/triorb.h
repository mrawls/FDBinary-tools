
int triorb_rv ( double *op, double t, double *rv );
#define TRIORB_NP 13

